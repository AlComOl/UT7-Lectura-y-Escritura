package Practica;

import java.io.*;
import java.util.*;



/************************************
 * @autor Alvaro Comenge Oliver
 * 
 * @Practica 17/05/24
 * @descripcion Ficheros
 * 
 * No se porque no me carga el ficherio , no 	qcreo que sea muy grave el error 
 * 
 *******************************/







public class TestMain {

	static Scanner  sc=new Scanner (System.in);
		
		
		
		public static void getMenu(){
			 
	        System.out.println("Elige una opcion:");
	        System.out.println("1.Añadir Receta");
	        System.out.println("1.Eliminar receta");
	        System.out.println("2.modificar Receta");
	        System.out.println("3.Listado de Objetos html");
	        System.out.println("4.Listado de recetas de un tiop de receta");
	        System.out.println("0. Salir");
	        
	 }	 
	
	public static void main(String[] args) throws IOException {
		 
		
		
		Scanner sc=new Scanner(System.in);
		int key;
		
		ArrayList<Receta>  coleccion=new ArrayList<Receta>();
		String nfichero="receta.obj";
		
		
		crearFicheroObjetos(nfichero);//creamos el archivo 
		cargarDesdeArchivo(nfichero,coleccion);//anadir palabras
		
//		anadir palabras
		
		do {
		 getMenu();
		 key=sc.nextInt();
		
		
			switch (key) {
			case 1: 
					
				AnyadirReceta(coleccion);
				llenarFicheroObjetos("recetas.obj",coleccion);
			
			break;
			case 2: 
				System.out.println("Dime receta que quieres eliminar");
				String p=sc.next();
				
				System.out.println("Introduce codigo receta");
				int codigo=sc.nextInt();
				//v.buscarTraduccion(p,idioma);
			
			break;
			case 3:
				System.out.println("Introduce el codigo de la receta que quieres modificar");
				String palabra=sc.next();
				System.out.println("Introduce la palabra nueva");
				String pamodificar=sc.next();
				
			
				
			break;
			case 4:
				System.out.println("Introduce palabra a eliminar");
				String eliminar=sc.next();
				
				
				
			break;
			
			case 5:
				System.out.println( coleccion.toString());
			break;
			case 6:
				System.out.println("Adios");
			break;
			default :
				System.out.println("La opcion no esta contemplada");
			}
			
		}while(key!=6);
		
		
		
		
		sc.close();
	

	}

	
	
	 public static void AnyadirReceta(ArrayList<Receta> coleccion) {
			/***********************************************************
			 * @author acome
			 * 
			 * @descripcion Este método se encarga de cargar palabras en
			 * el el array de recetas
			 * 
			 * ***********************************************************/
		    
		     int codigo;
			 String titulo;
			 String tipo;
			 int dificultad;
		    
		    int i,n;//numero de palabras a leer N 
		    
		    do {
		    	System.out.println("Numero el numero de recetas que quieres cargar");
		    	n=sc.nextInt();
		    }while(n<0);
		    sc.nextLine();

		   
		    for(i=1;i<=n;i++) {
		    	System.out.println("Receta "+i);
		    	System.out.println("Anyade codigo de la receta(int)");
		    	codigo=sc.nextInt();
		    	sc.nextLine();
		    	System.out.println("Antade titulo de la receta(string)");
		    	titulo=sc.nextLine();
		    	
		    	System.out.println("Anyade tipo de la receta(primero segudo postre otro");
		    	tipo=sc.nextLine();
		    	System.out.println("Anyade difucultad de la receta(de 1 a 5)");
		    	dificultad=sc.nextInt();
		    	
		    
		    	//introduzco en la instancia el valor
		    	Receta  c=new Receta(codigo,titulo,tipo,dificultad);
//		    	Palabra instancia =new Palabra(espanol,ingles,frances);
			    //por medio de add la instancia en el arraylist<palabra>
		    	coleccion.add(c);
		    	
		    	
		    }
		}
	 
	 /***
	     * Esta funcion carga el fichero pasado a la funcion en el arrayListr de tipo <receta>
	     * del vocavulario
	     * @param fichero
	     */
	    public static void cargarDesdeArchivo(String fichero,ArrayList<Receta> coleccion) {
	        try {
	            // Paso 1: Crear FileInputStream para leer el archivo de objetos
	            FileInputStream fileInputStream = new FileInputStream(fichero);
	            // Paso 2: Crear ObjectInputStream para leer objetos del archivo
	            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
	            boolean finArchivo = false;
	            while (!finArchivo) {
	                try {
	                    Receta r = (Receta) objectInputStream.readObject();
	                    if (r == null) {
	                        finArchivo = true;
	                    } else {
	                        coleccion.add(r);
	                        System.out.println("El archivo se añadio al array de recetas");
	                    }
	                } catch (EOFException e) {
	                    System.out.println("Se ha alcanzado el final del archivo.");
	                    finArchivo = true; 
	                }
	            }
	            objectInputStream.close(); // Es importante cerrar el ObjectInputStream después de su uso, sino se queda bloqueado
	        } catch (IOException | ClassNotFoundException e) {
	            System.out.println("Error al leer el archivo: " + e.getMessage());
	        }
	    }
	    
	    
	    
	    /*
	     * 
	     * 
	     * 
	     * @autor alvaro
	     */
	    public static void llenarFicheroObjetos(String fichero,ArrayList<Receta> coleccion) throws SecurityException, IOException {
	    	FileOutputStream fo=null;
	    	MiObjectOutputStream mObject=null;
	    	
	    try {
	    	 fo=new FileOutputStream(fichero);//acceder
	    	 mObject=new MiObjectOutputStream(fo);//escribir
	    	
	    	for(Receta c:coleccion){
	    		
	    		mObject.writeObject(c);	
	    	
	    	}
	    	mObject.flush();
	    }catch(IOException e) {
	    	
	    	System.out.println("Error al escribir el archivo :"+e.getMessage());
	    } finally {
	    	if (mObject != null) {
	            try {
	                mObject.close();
	            } catch (IOException e) {
	                System.out.println("Error al cerrar el MiObjectOutputStream: " + e.getMessage());
	            }
	        }
	        if (fo != null) {
	            try {
	                fo.close();
	            } catch (IOException e) {
	                System.out.println("Error al cerrar el FileOutputStream: " + e.getMessage());
	            }
	        }
	    }
	}
	    
	    
	    
	    /**
	     * @throws IOException ************************************
	     * 
	     * 
	     * 
	     * 
	     *************************************/
	   public static void crearFicheroObjetos(String nfichero) throws IOException {//crear fichero cargado
		   File f=new File(nfichero);//crea Fichero
		   FileOutputStream fos=new FileOutputStream(f);//hace de tuberia canaliza info
		   
		   ObjectOutputStream os= new ObjectOutputStream(fos);//poder manejar el objeto en el fichero con las funciones
		   
		   Receta c = new Receta(1,"house","maison",1);
		   
		   os.writeObject(c);
		   
	   }
	   
	 
		
}
